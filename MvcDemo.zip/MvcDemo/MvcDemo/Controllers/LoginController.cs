﻿using MvcDemo.Models;
using Sitecore.ApplicationCenter.Applications;
using Sitecore.Collections;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View("~/Views/Login/Login.cshtml");
        }
        [HttpPost]
     
        public ActionResult Validate(LoginModel login)
        {
            if (!ModelState.IsValid)
               return PartialView("~/Views/Login/Login.cshtml");

            string domainName = "sitecore";
            if (!System.Web.Security.Membership.ValidateUser(domainName + @"\" + login.sc_Name, login.sc_Password))
            {
                ViewData["Login"] = "Invalid";
                return View("http://sitecoreteam/Admin");
            }
            Session["User"] = login.sc_Name;
            return Redirect("http://sitecoreteam/Admin");

        }
       
        public ActionResult SessionCheck()
        {
            if (Session["User"] != null)
                return null;
            else
                return Redirect("http://sitecoreteam/Login");
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            Session.Clear();
            return Redirect("http://sitecoreteam/Login");
        }
    }

    
}