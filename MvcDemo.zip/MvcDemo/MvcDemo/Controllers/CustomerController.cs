﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcDemo.DAL;
using MvcDemo.Models;
using System.Text.RegularExpressions;
namespace MvcDemo.Controllers
{
    public class CustomerController : Controller
    {
        

        // GET: Customer
        public ActionResult Index()
        {
            InsuranceEntities db = new InsuranceEntities();

            // CusData t = new CusData();

            //var details = from customer in db.CUSTOMERS
                          //select new CUSTOMER() { Name = customer.Name, Age = customer.Age, Email = customer.Email };
            var details = from customer in db.CUSTOMERS.Take(10)
                    select new CusData() { name = customer.Name, age = customer.Age, email =customer.Email,  };
            
            
           // c.ToList();
           
            return PartialView(details);
            //return View(t.custData);
           // return View("~/Views/Customer/Customer.cshtml");
        }

        // GET: Customer/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Customer/Create
        public ActionResult Create()
        {
            return View();
        }
       [HttpPost]
        public ActionResult Createcustomer(CusPremiumDetails collection)
        {

            if (string.IsNullOrEmpty(collection.Email))
            {
                ModelState.AddModelError("Email", "Email is required");
            }
            if (string.IsNullOrEmpty(collection.Contact))
            {
                ModelState.AddModelError("Contact", "Contact is required");
            }

            if (ModelState.IsValid)
            {
                InsuranceEntities db = new InsuranceEntities();
                CUSTOMER cusData = new CUSTOMER();
                cusData.ID = Guid.NewGuid();
                cusData.Age = collection.Age;
                cusData.Email = collection.Email;

                cusData.Name = collection.Name;
                cusData.Contact = collection.Contact;
                db.CUSTOMERS.Add(cusData);
                db.SaveChanges();
                return View();
            }
            //return Content("");
            else
            {
                return View("~/Views/Validate.cshtml");
            }
                   /*  return View("~/Views/Calculator.cshtml");*/
           
        }

        // POST: Customer/Create
        [HttpPost]
        public ActionResult Create(CUSTOMER collection)
        {
            try
            {
                return View();
                
            }
            catch
            {
                return Content("some issue");
            }
        }

        // GET: Customer/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Customer/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Customer/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        public ActionResult validate()
        {
            return View("~/Views/Validate.cshtml");
        }

        [HttpPost]
       
        public ActionResult validate(CusPremiumDetails data)
        {
            if (string.IsNullOrEmpty(data.Name))
            {
                ModelState.AddModelError("Name", "Name required");
            }
            if (string.IsNullOrEmpty(data.Email))
            {
                ModelState.AddModelError("Email", "Name required");
            }

            if (ModelState.IsValid)
            {
                return View("~/Views/Validate.cshtml");
            }
            else
                //return View("~/Views/Validate.cshtml");
                return  View(data);
        }
        // POST: Customer/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }

   
}
