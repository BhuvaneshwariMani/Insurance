﻿using MvcDemo.Models;
using Sitecore.Security.Accounts;
using Sitecore.Security.Domains;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Controllers
{
    public class AnnouncementsController : Controller
    {
        InsuranceEntities db = new InsuranceEntities();
        // GET: Announcements
        public ActionResult Index()
        {

            var announceList = from announce in db.Announcents.Where(x => x.EndDate >= DateTime.Today)
                               select new Announcements() { Title = announce.Title, Description = announce.Description,EndDate=announce.EndDate };
           
            return View(announceList);


            // return View();
        }

        public ActionResult GetDetails()
        {
            
            //InsuranceEntities db = new InsuranceEntities();
            var announceList = from announce in db.Announcents
                               select new Announcements() { Title = announce.Title, Description = announce.Description, EndDate = announce.EndDate, Number = announce.Number,url=announce.url,SelectedUserID=announce.Owner };
            var announce1 = announceList.OrderBy(i => i.Title).OrderBy(i => i.EndDate).OrderBy(i => i.SelectedUserID);
          
            return View(announce1);
        }

        // GET: Announcements/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Announcements/Create
        public ActionResult Create()
        {
           // List<User> model = new List<User>();
           var users = Domain.GetDomain("sitecore").GetUsers();

            Announcements a = new Announcements();
            //a.ownerList = new SelectList(users, "", "");

            List<SelectListItem> userList = new List<SelectListItem>();
            foreach (var i in users)
            {
                userList.Add(new SelectListItem { Text =i.LocalName, Value = i.LocalName });
               
            }
            a.ownerList = userList;

            ViewData["owner"] = userList;
            // ViewBag.ownerList = new SelectList(users.l, "SubjectName", "SubjectName");

            // ViewBag.list = model;

            return View(a);
        }

        public ActionResult Detail(Announcements announce)
        {
            //InsuranceEntities db = new InsuranceEntities();
            try
            {
                //Session["Title"] = announce.Title;
                //Session["Description"] = announce.Description;
               
                TempData["Title"]=announce.Title;
                TempData["Description"]=announce.Description;
                TempData["EndDate"]=announce.EndDate;

                //ViewData["Title"] = announce.Title;
                //var announceList = from data in db.Announcents.Where(x => x.Title.Equals(announce.Title))
                //                   select new Announcements() { Title = data.Title, Description = data.Description };
                //Announcements announceData = new Announcements();
                //announceData.Title = announce.Title;
                return Redirect("http://sitecoreteam/announcement");
                //                return View(announceList);


                // return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // POST: Announcements/Create
        [HttpPost]
        public ActionResult Create(Announcements announce)
        {
            InsuranceEntities db = new InsuranceEntities();
            try
            {

                var announceList = from data in db.Announcents.Where(x => x.Title.Equals(announce.Title))
                                   select new Announcements() { Title = data.Title, Description = data.Description };

                //return Redirect("http://sitecoreteam/announcement");                          
                return View(announceList);


                // return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Createuser(Announcements announce)
        {

            if (ModelState.IsValid)
            {
                // InsuranceEntities db = new InsuranceEntities();
                Announcent announcedata = new Announcent();
                announcedata.Title = announce.Title;
                announcedata.Description = announce.Description;
                announcedata.EndDate = announce.EndDate;
                announcedata.Owner = announce.SelectedUserID;
                announcedata.url = announce.url;

                db.Announcents.Add(announcedata);
                db.SaveChanges();
                return Redirect("http://sitecoreteam/Announcement%20Report");
                // return RedirectToAction("GetDetails");
            }
            else 
                return View("~/Views/Announcements/Create.cshtml");
            
            //return View();
            //return Content("");


        }
        [HttpGet]
        // GET: Announcements/Edit/5
        public ActionResult Edit(int id)
        {
          //  InsuranceEntities db = new InsuranceEntities();
           
            var Details = from announcement in db.Announcents.Where(i => i.Number.Equals(id))
                               select new Announcements() { Title = announcement.Title, Description = announcement.Description, EndDate = announcement.EndDate, Number=announcement.Number,url=announcement.url,SelectedUserID=announcement.Owner };

            return View(Details);
        }


        //// POST: Announcements/Edit/5
        [HttpPost]
        public ActionResult Edit(Announcements data)
        {
            try
            {
                //var updateRecord = db.Announcents.SingleOrDefault(i => i.Number.Equals(data.Number));
                //updateRecord.Title = data.Title;
                //updateRecord.Description = data.Description;
                //updateRecord.EndDate = data.EndDate;
                //db.SaveChanges();

                //// TODO: Add update logic here

                //return RedirectToAction("GetDetails");
                return Redirect("http://sitecoreteam/Announcement%20Report");
            }
            catch
            {
                return View();
            }
        }
        [HttpPost]
        public ActionResult Update(Announcements data)
        {
            try
            {
                var updateRecord = db.Announcents.SingleOrDefault(i => i.Number.Equals(data.Number));
                updateRecord.Title = data.Title;
                updateRecord.Description = data.Description;
                updateRecord.EndDate = data.EndDate.ToLocalTime();
                updateRecord.url = data.url;
                updateRecord.Owner = data.SelectedUserID;
                db.SaveChanges();

                // TODO: Add update logic here
                return Redirect("http://sitecoreteam/Admin");
                //return RedirectToAction("GetDetails");
            }
            catch
            {
                return View();
            }
        }

        // GET: Announcements/Delete/5
        public ActionResult Delete(int id)
        {
            InsuranceEntities db = new InsuranceEntities();

            var user = db.Announcents.SingleOrDefault(i => i.Number.Equals(id));
            if (user != null)
            {
                db.Announcents.Remove(user);
                db.SaveChanges();
            }
            return Redirect("http://sitecoreteam/Announcement%20Report");
                //RedirectToAction("GetDetails");
        }

        // POST: Announcements/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
