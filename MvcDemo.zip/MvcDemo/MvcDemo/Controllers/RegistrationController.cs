﻿using MvcDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Controllers
{
    public class RegistrationController : Controller
    {
        // GET: Registration
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult RegistrationForm()
        {
            //BindCountry();
           // BindCity(0);
            return View("~/Views/Registration.cshtml");
        }

        [HttpPost]
        public ActionResult RegistrationForm(RegistrationModel mRegister)
        {
            //This will check Server Side Validation by using data annotation
            if (ModelState.IsValid)
            {
                return View("Completed");
            }
            else
            {
                // To DO: if client validation failed
                ViewBag.Selpwd = mRegister.Password; //for setting password value
                ViewBag.Selconfirmpwd = mRegister.ConfirmPassword;
                ViewBag.SelCountry = mRegister.Country; // for setting selected country
               // BindCountry();
                ViewBag.SelCity = mRegister.City;// for setting selected city

                //if (mRegister.Country != null)
                ////    BindCity(mRegister.Country.ID);
                //else
                //    BindCity(null);

                return View("~/Views/Registration.cshtml");
            }
        }
    }
}