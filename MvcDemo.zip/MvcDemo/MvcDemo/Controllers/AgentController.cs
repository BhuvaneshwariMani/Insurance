﻿using MvcDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;    
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Controllers
{
    public class AgentController : Controller
    {
        // GET: Agent
        public ActionResult Index()
        {
            InsuranceEntities db = new InsuranceEntities();
            var agentList = from agent in db.AGENTS
                            select new AgentList() { AgentState = agent.AgentState };
            return View(agentList);
        }
        public ActionResult Search(string state)
        {
            InsuranceEntities db = new InsuranceEntities();
                var agentDetails = from agent in db.AGENTS.Where(i=> i.AgentState.Equals(state))
                                  select new AgentList() { AgentName = agent.AgentName, AgentEmail = agent.AgentEmail, AgentContact = agent.AgentContact };
                return View(agentDetails);
        }
        // GET: Agent/Details/5
        //[HttpPost]
        //public ActionResult Search(string  state)
        //{
        //    InsuranceEntities db = new InsuranceEntities();
        //    var agentDetails = from agent in db.AGENTS.Where(i=> i.AgentState.Equals(state))
        //                       select new AgentList() { AgentName = agent.AgentName, AgentEmail = agent.AgentEmail, AgentContact = agent.AgentContact };
        //    return View();
        //}

        // GET: Agent/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: Agent/Create
       
        //public ActionResult Create(FormCollection collection)
        //{
        //    try
        //    {
               
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        // GET: Agent/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Agent/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Agent/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Agent/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
