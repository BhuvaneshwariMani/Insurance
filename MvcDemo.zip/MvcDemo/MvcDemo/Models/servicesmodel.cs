﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class servicesmodel: Sitecore.Mvc.Presentation.RenderingModel
    {
        public override void Initialize(Sitecore.Mvc.Presentation.Rendering rendering)
        {
            base.Initialize(rendering);
            servicesList = Sitecore.Data.ID.ParseArray(Item["serviceslist"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
        }


        public IList servicesList { get; private set; }

    }

}
