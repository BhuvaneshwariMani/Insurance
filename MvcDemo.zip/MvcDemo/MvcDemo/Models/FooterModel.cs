﻿using Sitecore.Mvc.Presentation;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class FooterModel: RenderingModel
    {
        public override void Initialize(Rendering rendering)
        {
            base.Initialize(rendering);
            footerList = Sitecore.Data.ID.ParseArray(Item["FooterMenuList"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
        }
        public IList footerList { get; private set; }
    }
}