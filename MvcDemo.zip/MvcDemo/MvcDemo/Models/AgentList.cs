﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class AgentList
    {
        public string AgentName { get; set; }
        public string AgentEmail { get; set; }
        public string AgentContact { get; set; }
        public string AgentState { get; set; }
    }
}