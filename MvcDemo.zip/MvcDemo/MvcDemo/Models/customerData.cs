﻿using Sitecore.Mvc.Presentation;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcDemo.Controllers
{
    public class customerData 
    {
        public customerData()
        {
        }
        
        //[Required (ErrorMessage = "age is required")]
        public int age { get; internal set; }
        //[Required (ErrorMessage ="Email is Required")]
        public string email { get; internal set; }
        //[Required(ErrorMessage = "name is Required")]
        public string name { get; internal set; }

        public IList custData { get; set; }

    }
}

