﻿
using Sitecore.Data.Items;
using Sitecore.Mvc.Presentation;
using Sitecore.Web.UI.WebControls;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Models
{
    public class Menu : Sitecore.Mvc.Presentation.RenderingModel
    {
        //private object ViewBag;

        public override void Initialize(Sitecore.Mvc.Presentation.Rendering rendering)
        {
            base.Initialize(rendering);
            MenuList = Sitecore.Data.ID.ParseArray(Item["Menu List"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
            Item item = rendering.Item;

            string countryList = item["Country"];
            NameValueCollection countryNameValueCollection = Sitecore.Web.WebUtil.ParseUrlParameters(countryList);
            foreach (string countryName in countryNameValueCollection)
            {
                var siteURL = countryNameValueCollection[countryName];
                siteList.Add(new SelectListItem { Text = countryName, Value = siteURL });
            }

        }


        public IList MenuList { get; private set; }
        public List<SelectListItem> siteList = new List<SelectListItem>();


    }
}