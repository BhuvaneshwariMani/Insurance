﻿using System.Linq;
using System.Collections;
using Sitecore.Data.Items;


namespace MvcDemo.Models
{
    public class insurancepagemodel: Sitecore.Mvc.Presentation.RenderingModel
    {
        public override void Initialize(Sitecore.Mvc.Presentation.Rendering rendering)
        {
            base.Initialize(rendering);
            insurancepageList = Sitecore.Data.ID.ParseArray(Item["ProductList"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
            
            //string s = Tracker.Current.Interaction.GeoData.Country;
        }


        public IList insurancepageList { get; private set; }

    }
}