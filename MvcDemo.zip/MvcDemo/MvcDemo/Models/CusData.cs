﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class CusData  
    {
        public int age { get;  set; }
        public string email { get;  set; }
        public string name { get;  set; }

        public IList custData { get; set; }
        
    }
}