﻿using Sitecore.Data.Items;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class Pods: Sitecore.Mvc.Presentation.RenderingModel
    {
        public override void Initialize(Sitecore.Mvc.Presentation.Rendering rendering)
        {
            base.Initialize(rendering);
            PodOneList = Sitecore.Data.ID.ParseArray(Item["Pod One List"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
            PodTwoList = Sitecore.Data.ID.ParseArray(Item["Pod Two List"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
            PodThreeList = Sitecore.Data.ID.ParseArray(Item["Pod Three List"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
            Item item = rendering.Item;
            InsuranceEntities db = new InsuranceEntities();

            var announceList = from announce in db.Announcents.Where(x => x.EndDate >= DateTime.Today)
                               select new Announcements() { Title = announce.Title, Description = announce.Description, EndDate = announce.EndDate, url = announce.url };
            details = announceList.ToList();

        }
        //public class Announcements : IEnumerable
        //{
        //    public int Number { get; set; }
        //    [Required(ErrorMessage = "Title Required")]
        //    public string Title { get; set; }
        //    [Required(ErrorMessage = "Description Required")]
        //    public string Description { get; set; }
        //    //[DisplayFormat(ApplyFormatInEditMode = true,
        //    //       DataFormatString = "{0:MM/dd/yyyy}")]

        //    [Required(ErrorMessage = "End Date Required")]
        //    public Nullable<System.DateTime> EndDate { get; set; }
        //    public IList AnnounceData { get; set; }

        //    public IEnumerator GetEnumerator()
        //    {
        //        throw new NotImplementedException();
        //    }
        //}
        public IList PodOneList { get; private set; }
        public IList PodTwoList { get; private set; }
        public IList PodThreeList { get; private set; }
       public List<Announcements> details = new List<Announcements>();
        //public Announcements details { get; set; }


        // testc<Announcements> = new Announcements();
    }
}