﻿using Sitecore.Security.Accounts;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Models
{


    public class Announcements : IEnumerable
    {
        public int Number { get; set; }
        [Required(ErrorMessage = "Title Required")]
        [Display(Name = "Title Please")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Description Required")]
        public string Description { get; set; }
        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MM-yy}")]

        [Required(ErrorMessage = "End Date Required")]
        public DateTime EndDate { get; set; }
        //public DateTime EndDate
        //{
        //    get { return endDate; }
        //    set { endDate = value; }
        //}
        //private DateTime endDate = DateTime.Now.ToUniversalTime();

        public string url { get; set; }

        public string SelectedUserID { get; set; }
        public List<SelectListItem> ownerList { get; set; }

        public IList AnnounceData { get; set; }

        public List<Announcements> newAnnouncement = new List<Announcements>();

        public IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}