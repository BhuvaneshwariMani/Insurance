﻿using Sitecore.Mvc.Presentation;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class Class1: Sitecore.Mvc.Presentation.RenderingModel
    {
        public override void Initialize(Rendering rendering)
        {
            base.Initialize(rendering);
            CarouselSlides =
                Sitecore.Data.ID.ParseArray(Item["BannerList"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
        }

        public IList CarouselSlides { get; private set; }
    }
}