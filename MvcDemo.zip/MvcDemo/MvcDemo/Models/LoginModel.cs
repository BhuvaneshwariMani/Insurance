﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemo.Models
{
    public class LoginModel
    {
        [Required (ErrorMessage="User name is mandatory")]
        [Display(Name ="User Name:")]
        public string sc_Name { get; set; }

        [Required(ErrorMessage ="Password is mandatory")]
        [Display(Name = "Password:")]
        public string sc_Password { get; set; }
    }
}