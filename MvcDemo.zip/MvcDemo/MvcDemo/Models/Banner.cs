﻿using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data.Items;
using System.Collections;
using Sitecore.Web.UI.WebControls;
using System.ComponentModel.DataAnnotations;

namespace MvcDemo.Models
{
    //public partial class CUSTOMER
    //{
    //    public System.Guid ID { get; set; }
    //    public string Name { get; set; }
    //    public int Age { get; set; }
    //    public string Email { get; set; }
    //    public string Contact { get; set; }
    //    public string Duration { get; set; }
    //}

    public class Banner: List<Banner>, IRenderingModel
    {
        public Sitecore.Mvc.Presentation.Rendering Rendering { get; set; }
        public Item Item { get; set; }
        public virtual string img { get; set; }
        public virtual string link { get; set; }
        public int countBanner;
        public List<Banner> Slides = new List<Banner>();
        public Banner() { }

        public System.Guid ID { get; set; }
        //[RegularExpression("[a-zA-Z]", ErrorMessage = "only alphabet")]
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        [Range(15, 60, ErrorMessage = "Enter number between 15 to 60")]
        [Required(ErrorMessage = "Age is required")]
        public int Age { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Contact is required")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Entered phone format is not valid.")]
        public string Contact { get; set; }

        public Banner(Item item,int j)
        {
            this.img = FieldRenderer.Render(item, "Image");
            this.link = Sitecore.Links.LinkManager.GetItemUrl(item);
            countBanner = j;
           
        }
        public  void Initialize(Sitecore.Mvc.Presentation.Rendering rendering)
        {
            Rendering = rendering;
            Item = rendering.Item;
            
            CarouselSlides =
                Sitecore.Data.ID.ParseArray(Item["BannerList"])
                    .Select(id => Item.Database.GetItem(id)).ToList();
            var i = 0;
            foreach (Item child in CarouselSlides)
            {
                Banner obj = new Banner(child,i++);
                Slides.Add(obj);
                
            }

        }
     
        public IList CarouselSlides { get; private set; }
        //public System.Guid ID { get; set; }
        //  public string Name { get; set; }
        //  public int Age { get; set; }
        //   public string Email { get; set; }
        //    public string Contact { get; set; }
        //   public string Duration { get; set; }
    }
}