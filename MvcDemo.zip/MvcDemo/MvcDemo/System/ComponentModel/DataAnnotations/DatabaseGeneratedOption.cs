﻿namespace System.ComponentModel.DataAnnotations
{
    internal class DatabaseGeneratedOption
    {
    }
}