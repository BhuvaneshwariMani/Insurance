﻿using System;

namespace MvcDemo.DAL
{
    internal class requiredAttribute : Attribute
    {
    }
}